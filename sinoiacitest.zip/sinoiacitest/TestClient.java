import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * �����ܼ�顿���Խӿڵĳ���<br>
 * ����֪���⡿<br>
 * 1���ܶ��ַ�����Ҫ�������� <br>
 * 2�����ÿһ���򿪵��ļ��������Ƿ�رա�
 * 3��line1��line2ʹ�õ������졣
 * 
 * @author �п����Ƽ�
 * @version 1.0.0 build0829 ������ �����������ڱ��ص��ԡ�
 * @version 1.0.1 build0829 ������ �޸����밴�����ļ���ȡ��
 */
public class TestClient {

	/**
	 * �ͻ����������� <br>
	 * args[0] - URL��ַ���磺http://192.168.60.30:8001/sinoiaci/CommServer�� <br>
	 * args[1] - �ļ����ƣ��磺./postbatch.xml��<br>
	 * args[2] - ��־���ƣ��磺./postbatch.log��<br>
	 * 
	 * @param args��
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		String logFile = null;
		String line0 = "";
		String line1 = "--------------------------------------------------------------------------------";
		String line2 = "================================================================================";

		HttpURLConnection httpConnection = null;
		OutputStream outputStream = null;
		BufferedReader bufferedReader1 = null;
		BufferedReader bufferedReader2 = null;
		InputStreamReader inputStreamReader = null;

		try {
			String lineString = "";

			SimpleDateFormat formatter = new SimpleDateFormat(
					"[yyyy-MM-dd HH:mm:ss.SSS] - ");

			/*******************************************************************
			 * 0��������Ϣ
			 ******************************************************************/
			String url = args[0];
			String file = args[1];
			logFile = args[2];

			writeLog(line0, logFile, true, true);
			writeLog(line2, logFile, true, true);
			writeLog(formatter.format(new Date()) + "CommClient start! ",
					logFile, true, true);
			writeLog(line1, logFile, true, true);

			writeLog("args[0] = " + url, logFile, true, true);
			writeLog("args[1] = " + file, logFile, true, true);
			writeLog("args[2] = " + logFile, logFile, true, true);
			writeLog(line1, logFile, true, true);

			/*******************************************************************
			 * 1��������
			 ******************************************************************/
			httpConnection = (HttpURLConnection) new URL(url).openConnection();

			httpConnection.setRequestMethod("POST");
			httpConnection.setDoOutput(true);
			httpConnection.setDoInput(true);
			httpConnection.setAllowUserInteraction(true);

			httpConnection.connect();

			/*******************************************************************
			 * 2����������
			 ******************************************************************/
			outputStream = httpConnection.getOutputStream();

			bufferedReader1 = new BufferedReader(new FileReader(file));
			StringBuilder sbInput = new StringBuilder();

			// - д�����
			while ((lineString = bufferedReader1.readLine()) != null) {
				byte readByte[] = lineString.getBytes("GBK");
				outputStream.write(readByte, 0, readByte.length);
				sbInput.append(lineString.replaceAll("\t", "").trim());
			}
			outputStream.flush();

			// - ��¼�ļ�
			lineString = sbInput.toString();

			writeLog(lineString, logFile, true, true);
			writeLog(line1, logFile, true, true);
			writeLog(lineString, logFile + ".i.xml", false, false);

			/*******************************************************************
			 * 3����������
			 ******************************************************************/
			inputStreamReader = new InputStreamReader(httpConnection
					.getInputStream());
			bufferedReader2 = new BufferedReader(inputStreamReader);

			StringBuffer sbOutput = new StringBuffer(1024);
			while ((lineString = bufferedReader2.readLine()) != null) {
				sbOutput.append(lineString);
			}

			/*******************************************************************
			 * 4����¼��־
			 ******************************************************************/
			lineString = sbOutput.toString();

			writeLog(lineString, logFile, true, true);
			writeLog(line1, logFile, true, true);
			writeLog(formatter.format(new Date()) + "CommClient finish! ",
					logFile, true, true);
			writeLog(line2, logFile, true, true);
			writeLog(lineString, logFile + ".o.xml", false, false);

		} catch (Exception e) {
			e.printStackTrace();

			// ��¼������Ϣ��
			if (logFile != null) {
				writeLog(e.toString(), logFile, true, true);
			}
		} finally {
			try {
				outputStream.close();
			} catch (Exception e) {
				// Nothing;
			}

			try {
				bufferedReader1.close();
			} catch (Exception e) {
				// Nothing;
			}

			try {
				bufferedReader2.close();
			} catch (Exception e) {
				// Nothing;
			}

			try {
				inputStreamReader.close();
			} catch (Exception e) {
				// Nothing;
			}
			
			try {
				httpConnection.disconnect();
			} catch (Exception e) {
				// Nothing;
			}
		}
	}

	/**
	 * ��¼��־
	 * 
	 * @param text
	 * @return
	 * @throws Exception
	 */
	public static void writeLog(String text, String file, boolean append,
			boolean console) throws Exception {

		FileWriter fileWriter = null;

		try {
			fileWriter = new FileWriter(file, append);

			// ��¼����̨
			if (console) {
				System.out.println(text);
			}

			// ��¼�ı�
			fileWriter.write(text + System.getProperty("line.separator"));
			fileWriter.flush();

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			if (fileWriter != null) {
				try {
					fileWriter.close();
				} catch (Exception e) {
					// Nothing.
				}
			}
		}
	}
}