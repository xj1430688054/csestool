启动说明：
	双击 启动.bat文件
用户名   s  
密码  s
日志会打印在当前目录下面 ， 请查看
	
数据库 mysql 123.57.216.177:3306  cses  root root

远程库调用地址：http://123.57.216.177:8080/sinoiaci/commserver

因目前就搭建了四川的数据库， 故单执行的时候就四川可以

db2 123.57.216.177:50000 iaci5100 iaca5100 instiaci password

交强险搭建地址：
	http://123.57.216.177:8080/sinoiaci/admin/
	缓存登录用户名密码    iaciadmin 123456

	
测试文件路劲: C:\Users\xj143\Desktop\sinoiacitest
请将zip包（报文）解压放在这个位置（到时候可以调式更改， 看放哪里合适）
	
